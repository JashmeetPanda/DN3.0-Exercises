package exercise_2_FactoryDesignPatternExample;

public interface Document {
	void open();
    void save();
    void close();
}
