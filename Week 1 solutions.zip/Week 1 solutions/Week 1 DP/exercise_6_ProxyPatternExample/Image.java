package exercise_6_ProxyPatternExample;

public interface Image {
    void display();
}